﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Balkezesek
{
    class Player
    {
        public Player(string sor)
        {
            var adatok = sor.Trim().Split(';');
            this.nev = adatok[0];
            this.elso = int.Parse(adatok[1].Substring(0, 4));
            this.utolso = int.Parse(adatok[2].Substring(0, 4));
            this.suly = int.Parse(adatok[3]);
            this.magassag = int.Parse(adatok[4]) * 2.54;
            this.utolso_evho = adatok[2].Substring(0, 7);
        }

        public string nev { get; set; }
        public int elso { get; set; }
        public int utolso { get; set; }
        public int suly { get; set; }
        public double magassag { get; set; }
        public string utolso_evho { get; set; }
    }
}
