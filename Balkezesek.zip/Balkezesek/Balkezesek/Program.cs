﻿using System.Text;

class Program
{
    public static void Main(string[] args)
    {
        // 2.
        var f = new StreamReader("balkezesek.csv", Encoding.Default);
        var lista = new List<Player>();
        var elsosor = f.ReadLine();

        while (!f.EndOfStream)
        {
            lista.Add(new Player(f.ReadLine()));
        }
        f.Close();

        // 3. adatsorok száma
        Console.WriteLine($"3. feladat: {lista.Count}");

        // 4. Játékosok, akik 1990-10-ben léptek utoljára pályára
        Console.WriteLine($"4. feladat:");

        foreach (var sor in lista)
        {
            if (sor.utolso_evho == "1999-10")
            {
                Console.WriteLine($"        {sor.nev}, {sor.magassag:0.#} cm");
            }
        }
        //5.
        Console.WriteLine($"5. feladat:");
        int ev;
        while (true)
        {
            Console.Write("Kérek egy 1990 és 1999 közötti évszámot!:");
            int.TryParse(Console.ReadLine(), out ev);
            if ((1990 < ev) & (ev < 1999))
            {
                break;
            }
            else
            {
                Console.Write("Hibás adat!");
            }
        }
        // 6. az adott évben pályára lépett játékosok átlagsúlya 
        var atlagsuly = (
            from sor in lista
            where sor.elso <= ev
            where ev <= sor.utolso
            select sor.suly
            ).Average();
        Console.WriteLine($"6. feladat: {atlagsuly:0.##} font");
    }
}